﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BestHomeLoan.BusinessLogic;
using BestHomeLoan.Model;
using System.Collections.Generic;
using System.Collections;
using System.Linq;

namespace PersonUnitTest
{
    [TestClass]
    public class UnitTest1
    {
        private Controller controller;
        
        [TestInitialize]
        public void initialize()
        {
            controller = new Controller();
        }
        [TestMethod]
        [ExpectedException(typeof(System.IO.FileNotFoundException))]
        public void ExtractDelimiterFileNotFound()
        {
            FileParser parser = new FileParser();
            parser.Parse("Imaginary.txt");
        }
     

        [TestMethod]
        public void ParseSuccessfull()
        {
            FileParser parser = new FileParser();
            List<Person> persons = parser.Parse("file1.txt");
            Assert.AreNotEqual(persons.Count, 0);
        }

        [TestMethod]
        public void TestGender()
        {
            String filename = "file1.txt";
            FileParser parser = new FileParser();
            List<Person> persons = parser.Parse(filename);
        

          
            String filename2 = "file2.txt";
            persons = persons.Concat(parser.Parse(filename2)).ToList();

          
            String filename3 = "file3.txt";
            persons = persons.Concat(parser.Parse(filename3)).ToList();

            Sorter sorter = new Sorter(persons);
            sorter.sortByGender();
        }

        [TestMethod]
        public void TestNameDesc()
        {
            String filename = "file1.txt";
            FileParser parser = new FileParser();
            List<Person> persons = parser.Parse(filename);



            String filename2 = "file2.txt";
            persons = persons.Concat(parser.Parse(filename2)).ToList();


            String filename3 = "file3.txt";
            persons = persons.Concat(parser.Parse(filename3)).ToList();

            Sorter sorter = new Sorter(persons);
            sorter.sortByLastNameDesc();
        }
        [TestMethod]
        public void TestDate()
        {
            String filename = "file1.txt";
            FileParser parser = new FileParser();
            List<Person> persons = parser.Parse(filename);



            String filename2 = "file2.txt";
            persons = persons.Concat(parser.Parse(filename2)).ToList();


            String filename3 = "file3.txt";
            persons = persons.Concat(parser.Parse(filename3)).ToList();

            Sorter sorter = new Sorter(persons);
            sorter.sortByDateDesc();
        }
    }
}
