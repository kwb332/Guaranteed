﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BestHomeLoan.BusinessLogic;
using BestHomeLoan.Model;

namespace BestHomeLoan
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Controller controller = new Controller();
                controller.loadPersons();

                Console.WriteLine("Output 1");
                Console.WriteLine(controller.OutPut1());
                Console.WriteLine("Output 2");
                Console.WriteLine(controller.OutPut2());
                Console.WriteLine("Output 3");
                Console.WriteLine(controller.OutPut3());
                Console.ReadLine();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }




        }
    }
}
