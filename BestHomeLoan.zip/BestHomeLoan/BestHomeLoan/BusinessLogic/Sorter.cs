﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BestHomeLoan.Model;

namespace BestHomeLoan.BusinessLogic
{
    public class Sorter
    {
        private List<Person> persons;
        public Sorter(List<Person> persons)
        {
            this.persons = persons;
        }
        public List<Person> sortByGender()
        {
            var femalePersons = persons.Where(x => x.Gender == "F").ToList();
            femalePersons = sortByLastNameAsc(femalePersons);

            var malePersons = persons.Where(x => x.Gender == "M").ToList();
            malePersons = sortByLastNameAsc(malePersons);

           return femalePersons.Concat(malePersons).ToList();

        }
        public List<Person> sortByDateDesc()
        {
            var byDate = persons.OrderByDescending(x => x.DateOfBirth).ToList();
            
            return byDate;

        }

        public List<Person> sortByLastNameDesc()
        {
            List<Person> curPerson = persons.OrderByDescending(x => x.LastName).ToList();
            return curPerson;
        }
        public List<Person> sortByLastNameAsc(List<Person> input)
        {
            List<Person> curPerson = input.OrderBy(x => x.LastName).ToList() ;
            return curPerson;
        }

    }
}

