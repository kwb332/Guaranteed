﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.IO;
using BestHomeLoan.Model;

namespace BestHomeLoan.BusinessLogic
{
    public class FileParser : IParser
    {
        public char ExtractDelimiter(string path)
        {

            StreamReader stream = new StreamReader(path);
            String firstline = stream.ReadLine();
            stream.Close();
            int index = firstline.IndexOf(",");
            if (index > 0)
                return ',';
            index = firstline.IndexOf("|");
            if (index > 0)
                return '|';
            index = firstline.IndexOf(" ");
            if (index > 0)
                return ' ';
            throw new DelimiterNotFound();

        }

        public List<Person> Parse(string path)
        {
            char delimiter = ExtractDelimiter(path);
        
            string line;

            // Read the file and display it line by line.  
            System.IO.StreamReader file =
                new System.IO.StreamReader(path);
            List<Person> persons = new List<Person>();
            while ((line = file.ReadLine()) != null)
            {
                String[] properties = line.Split(new char[] { delimiter });
                Person curPerson = new Person()
                {
                    LastName = properties[0],
                    FirstName = properties[1],
                    Gender = properties[2],
                    FavoriteColor = properties[3],
                    DateOfBirth = Convert.ToDateTime(properties[4])

                };
                persons.Add(curPerson);
            }

            file.Close();
            return persons;
          
        }
       
    }
}
