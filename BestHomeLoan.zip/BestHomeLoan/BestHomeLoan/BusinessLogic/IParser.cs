﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BestHomeLoan.Model;

namespace BestHomeLoan.BusinessLogic
{
    interface IParser
    {
        char ExtractDelimiter(string path);
        List<Person> Parse(String path);
    }
}
