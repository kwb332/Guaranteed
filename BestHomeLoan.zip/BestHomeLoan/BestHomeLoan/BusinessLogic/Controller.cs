﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BestHomeLoan.Model;
using System.Reflection;
using System.Web;
using System.IO;

namespace BestHomeLoan.BusinessLogic
{
    public class Controller
    {
        private IParser parser;
        private Sorter sorter;
        private List<Person> persons;
        public Controller()
        {
            persons = new List<Person>();
            parser = new FileParser();
           
        }
        public void loadPersons()
        {
          
            Console.WriteLine("Please enter the name of the first file");
            Console.Write(">");
            String filename = Console.ReadLine();

            persons =  parser.Parse(filename);
          

            Console.WriteLine("Please enter the name of the second file");
            Console.Write(">");
            String filename2 = Console.ReadLine();
            persons = persons.Concat(parser.Parse(filename2)).ToList();

            Console.WriteLine("Please enter the name of the third file");
            Console.Write(">");
            String filename3 = Console.ReadLine();
            persons = persons.Concat(parser.Parse(filename3)).ToList();

            sorter = new Sorter(persons);
        }
        public void loadPersonsApi()
        {

            string path = HttpContext.Current.Server.MapPath("~/App_Data");
            String filename = path+"\\file1.txt";
            persons = parser.Parse(filename);
         
            filename = path + "\\file2.txt";
            persons = persons.Concat(parser.Parse(filename)).ToList();


            filename = path + "\\file3.txt";
            persons = persons.Concat(parser.Parse(filename)).ToList();

            sorter = new Sorter(persons);
        }
        public void loadPerson(Person p, String filename, char delimiter)
        {

            string path = HttpContext.Current.Server.MapPath("~/App_Data");
            filename = path + "\\" + filename;  
           
            p.delimiter = delimiter;

            using (StreamWriter sw = File.AppendText(filename))
            {
                sw.WriteLine("\r"+p.ToString());
              
            }
           
          
             
        }
        public String OutPut1()
        {
            var genderlist = sorter.sortByGender();
            String result = "LastName\t\t\tFirstName\t\t\tGender\t\t\tFavoriteColor\tDateOfBirth" + Environment.NewLine;
            StringBuilder builder = new StringBuilder(result);
            foreach(Person p in genderlist)
            {
                builder.Append(p.LastName + "\t\t\t" + p.FirstName+ "\t\t\t" + p.Gender+ "\t\t\t" + p.FavoriteColor+ "\t" + p.DateOfBirth.ToString("MM/dd/yyyy") +Environment.NewLine);

            }
            return builder.ToString();

        }
        public String OutPut2()
        {
            var dateOfBirth = sorter.sortByDateDesc();
            String result = "LastName\t\t\tFirstName\t\t\tGender\t\t\tFavoriteColor\tDateOfBirth" + Environment.NewLine;
            StringBuilder builder = new StringBuilder(result);
            foreach (Person p in dateOfBirth)
            {
                builder.Append(p.LastName + "\t\t\t" + p.FirstName + "\t\t\t" + p.Gender + "\t\t\t" + p.FavoriteColor + "\t" + p.DateOfBirth.ToString("MM/dd/yyyy") + Environment.NewLine);

            }
            return builder.ToString();

        }
        public String OutPut3()
        {
            var genderlist = sorter.sortByLastNameDesc();
            String result = "LastName\t\t\tFirstName\t\tGender\t\tFavoriteColor\tDateOfBirth" + Environment.NewLine;
            StringBuilder builder = new StringBuilder(result);
            foreach (Person p in genderlist)
            {
                builder.Append(p.LastName + "\t\t\t" + p.FirstName + "\t\t\t" + p.Gender + "\t\t\t" + p.FavoriteColor + "\t" + p.DateOfBirth.ToString("MM/dd/yyyy") + Environment.NewLine);

            }
            return builder.ToString();

        }
        public List<Person> sortByGender()
        {
            var genderlist = sorter.sortByGender();
            return genderlist;

        }
        public List<Person> sortByDateDesc()
        {
            var dateOfBirth = sorter.sortByDateDesc();
            return dateOfBirth;

        }
        public List<Person> sortByLastNameDesc()
        {
            var lastname = sorter.sortByLastNameDesc();
            return lastname;

        }


    }
}
