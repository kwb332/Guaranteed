﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BestHomeLoan.BusinessLogic;
using BestHomeLoan.Model;

namespace PersonWebApi.Controllers
{
    public class ReportController : ApiController
    {
        private Controller controller = new Controller();
        // GET: api/Report
        [Route("api/record/gender")]
        [HttpGet]
        public IEnumerable<Person> gender()
        {
            controller.loadPersonsApi();
            return controller.sortByGender();
        }

        [Route("api/record/birthdate")]
        [HttpGet]
        
        public IEnumerable<Person> date()
        {
            controller.loadPersonsApi();
          
            return controller.sortByDateDesc();
        }
        [Route("api/record/name")]
        [HttpGet]
        public IEnumerable<Person> name()
        {
            controller.loadPersonsApi();
            return controller.sortByLastNameDesc();
        }
        [Route("api/records")]
        [HttpPost]
        public void Post()
        {
            Person person = new Person()
            {
                FirstName = "Tiger",
                LastName = "Wild",
                DateOfBirth = DateTime.Now,
                FavoriteColor = "Yellow"
            };

            controller.loadPersonsApi();
            controller.loadPerson(person, "file1.txt", ' ');
            
        }


        // PUT: api/Report/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Report/5
        public void Delete(int id)
        {
        }
    }
}
